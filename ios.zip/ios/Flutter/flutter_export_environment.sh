#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/minhphuonglogistics/development/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/minhphuonglogistics/SourceCode/1.Android_Project/igls_new"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.21"
export "FLUTTER_BUILD_NUMBER=33"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=false"
export "TREE_SHAKE_ICONS=true"
export "PACKAGE_CONFIG=/Users/minhphuonglogistics/SourceCode/1.Android_Project/igls_new/.dart_tool/package_config.json"
